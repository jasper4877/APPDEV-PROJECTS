const Home = () => <h1>Welcome to the Game App!</h1>;
export default Home;
