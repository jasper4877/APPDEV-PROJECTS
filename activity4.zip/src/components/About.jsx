const About = () => <h1>About Us: Learn more about this app.</h1>;
export default About;
