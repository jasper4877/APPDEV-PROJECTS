import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Import Components
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import ProductListing from './pages/ProductListing';
import ProductManual from './pages/ProductManual';
import Mission from './pages/Mission';
import CompanyProfile from './pages/CompanyProfile';
import Reviews from './pages/Reviews';
import ArtisanKeyboards from './pages/ArtisanKeyboards';
import Developers from './pages/Developers';

function App() {
  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        <Navbar />
        
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/products" element={<ProductListing />} />
            <Route path="/product/:id" element={<ProductManual />} />
            <Route path="/mission" element={<Mission />} />
            <Route path="/company-profile" element={<CompanyProfile />} />
            <Route path="/reviews" element={<Reviews />} />
            <Route path="/artisan-keyboards" element={<ArtisanKeyboards />} />
            <Route path="/developers" element={<Developers />} />
            <Route path="/employee/:id" element={<CompanyProfile />} />
          </Routes>
        </main>
        
        <Footer />
      </div>
    </Router>
  );
}

export default App;