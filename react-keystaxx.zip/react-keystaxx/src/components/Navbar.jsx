import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <nav className="bg-gray-800 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <div className="text-2xl font-bold">KeyStaxx</div>
        <div className="space-x-4">
          <Link to="/" className="hover:text-gray-300">Home</Link>
          <Link to="/products" className="hover:text-gray-300">Products</Link>
          <Link to="/mission" className="hover:text-gray-300">Mission</Link>
          <Link to="/company-profile" className="hover:text-gray-300">Company Profile</Link>
          <Link to="/reviews" className="hover:text-gray-300">Reviews</Link>
          <Link to="/artisan-keyboards" className="hover:text-gray-300">Artisan Keyboards</Link>
          <Link to="/developers" className="hover:text-gray-300">Developers</Link>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;