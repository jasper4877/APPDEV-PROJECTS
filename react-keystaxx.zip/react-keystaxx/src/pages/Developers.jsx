import React, { useState } from 'react';

function Developers() {
  const [vouchCount, setVouchCount] = useState(0);

  const developers = [
    {
      name: 'Alice Johnson',
      role: 'Lead Web Developer',
      skills: ['React', 'Node.js', 'UI/UX Design'],
      bio: 'Passionate about creating intuitive and beautiful web experiences.'
    },
    {
      name: 'Bob Smith',
      role: 'Frontend Engineer',
      skills: ['React', 'TypeScript', 'CSS Animations'],
      bio: 'Dedicated to pushing the boundaries of web design and functionality.'
    }
    // Add more developers
  ];

  const handleVouch = () => {
    setVouchCount(prevCount => prevCount + 1);
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Our Development Team</h1>
      
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold">Developer Vouch</h2>
        <p className="mb-4">Show your support for our awesome development team!</p>
        <div className="flex items-center justify-center space-x-4">
          <button 
            onClick={handleVouch}
            className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition"
          >
            Vouch for Developers
          </button>
          <span className="text-xl font-bold">Vouch Count: {vouchCount}</span>
        </div>
      </div>
      
      <div className="grid md:grid-cols-2 gap-6">
        {developers.map((developer, index) => (
          <div 
            key={index} 
            className="bg-gray-100 p-6 rounded-lg shadow-md hover:shadow-lg transition"
          >
            <h2 className="text-2xl font-semibold mb-2">{developer.name}</h2>
            <p className="text-gray-600 mb-2">{developer.role}</p>
            
            <div className="mb-4">
              <h3 className="font-bold mb-2">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {developer.skills.map((skill, skillIndex) => (
                  <span 
                    key={skillIndex} 
                    className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            
            <p className="italic">{developer.bio}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Developers;