import React from 'react';

function Mission() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Our Mission and Vision</h1>
      
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-gray-100 p-6 rounded-lg">
          <h2 className="text-2xl font-semibold mb-4">Mission Statement</h2>
          <p className="text-lg">
            At KeyStaxx, our mission is to revolutionize the mechanical keyboard experience 
            by creating high-quality, innovative, and personalized keyboards that cater to 
            both professional and enthusiast users. We strive to blend cutting-edge technology 
            with artistic craftsmanship, delivering keyboards that are not just tools, but 
            expressions of individual style and performance.
          </p>
        </div>
        
        <div className="bg-gray-100 p-6 rounded-lg">
          <h2 className="text-2xl font-semibold mb-4">Our Vision</h2>
          <p className="text-lg">
            We envision a world where every keystroke is a seamless blend of comfort, 
            precision, and personal expression. KeyStaxx aims to be the leading global 
            provider of premium mechanical keyboards, setting new standards in design, 
            functionality, and user experience.
          </p>
        </div>
      </div>
      
      <div className="mt-8">
        <h2 className="text-2xl font-semibold mb-4">Core Values</h2>
        <ul className="list-disc pl-5 space-y-2">
          <li>Innovation in Design</li>
          <li>Quality Craftsmanship</li>
          <li>Customer Satisfaction</li>
          <li>Sustainable Manufacturing</li>
          <li>Continuous Improvement</li>
        </ul>
      </div>
    </div>
  );
}

export default Mission;