import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const employees = [
  {
    id: 1,
    name: 'John Doe',
    position: 'CEO & Founder',
    department: 'Executive',
    imageUrl: '/path/to/john-doe.jpg'
  },
  {
    id: 2,
    name: 'Jane Smith',
    position: 'Chief Design Officer',
    department: 'Design',
    imageUrl: '/path/to/jane-smith.jpg'
  },
  // Add more employees
];

function CompanyProfile() {
  const [selectedDepartment, setSelectedDepartment] = useState('All');

  const filteredEmployees = selectedDepartment === 'All' 
    ? employees 
    : employees.filter(emp => emp.department === selectedDepartment);

  const departments = ['All', ...new Set(employees.map(emp => emp.department))];

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Company Profile</h1>
      
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-4">Department Filters</h2>
        <div className="flex space-x-4">
          {departments.map(dept => (
            <button
              key={dept}
              onClick={() => setSelectedDepartment(dept)}
              className={`px-4 py-2 rounded ${
                selectedDepartment === dept 
                  ? 'bg-blue-500 text-white' 
                  : 'bg-gray-200 text-gray-800'
              }`}
            >
              {dept}
            </button>
          ))}
        </div>
      </div>
      
      <div className="grid md:grid-cols-3 gap-6">
        {filteredEmployees.map(employee => (
          <div 
            key={employee.id} 
            className="border rounded-lg p-4 text-center hover:shadow-lg transition-shadow"
          >
            <img 
              src={employee.imageUrl} 
              alt={employee.name} 
              className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
            />
            <h2 className="text-xl font-semibold">{employee.name}</h2>
            <p className="text-gray-600">{employee.position}</p>
            <Link 
              to={`/employee/${employee.id}`} 
              className="mt-2 inline-block bg-blue-500 text-white px-4 py-2 rounded"
            >
              View Profile
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CompanyProfile;