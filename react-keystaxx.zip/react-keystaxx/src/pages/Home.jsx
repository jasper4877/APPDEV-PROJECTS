import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-4xl font-bold mb-4">Welcome to KeyStaxx</h1>
      <p className="text-lg mb-6">
        Crafting Exceptional Mechanical Keyboards for Enthusiasts and Professionals
      </p>
      
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-gray-100 p-4 rounded">
          <h2 className="text-2xl font-semibold mb-2">Our Products</h2>
          <Link to="/products" className="text-blue-600 hover:underline">
            Explore Our Keyboard Collection
          </Link>
        </div>
        
        <div className="bg-gray-100 p-4 rounded">
          <h2 className="text-2xl font-semibold mb-2">Mission & Vision</h2>
          <Link to="/mission" className="text-blue-600 hover:underline">
            Learn About Our Goals
          </Link>
        </div>
        
        <div className="bg-gray-100 p-4 rounded">
          <h2 className="text-2xl font-semibold mb-2">Customer Reviews</h2>
          <Link to="/reviews" className="text-blue-600 hover:underline">
            See What Our Customers Say
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Home;