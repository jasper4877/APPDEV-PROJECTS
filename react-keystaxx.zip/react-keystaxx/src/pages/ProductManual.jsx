import React, { useState, useParams } from 'react';

function ProductManual() {
  const { id } = useParams();
  const [reviews, setReviews] = useState([]);
  const [newReview, setNewReview] = useState('');

  // Mock product data (replace with actual product retrieval logic)
  const product = {
    id: id,
    name: 'KeyStaxx Pro Mechanical Keyboard',
    materials: 'Aluminum Frame, PBT Keycaps',
    switchType: 'Cherry MX Blue',
    connectionType: 'Wired USB-C',
    fullDescription: 'Detailed product description goes here...'
  };

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    if (newReview.trim()) {
      setReviews([...reviews, newReview]);
      setNewReview('');
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">{product.name} - Product Manual</h1>
      
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h2 className="text-2xl font-semibold mb-2">Product Specifications</h2>
          <ul className="list-disc pl-5">
            <li>Materials: {product.materials}</li>
            <li>Switch Type: {product.switchType}</li>
            <li>Connection: {product.connectionType}</li>
          </ul>
          
          <p className="mt-4">{product.fullDescription}</p>
        </div>
        
        <div>
          <h2 className="text-2xl font-semibold mb-2">Product Reviews</h2>
          
          <form onSubmit={handleReviewSubmit} className="mb-4">
            <textarea
              value={newReview}
              onChange={(e) => setNewReview(e.target.value)}
              placeholder="Write your review here..."
              className="w-full p-2 border rounded"
              rows="4"
            ></textarea>
            <button 
              type="submit" 
              className="mt-2 bg-blue-500 text-white py-2 px-4 rounded"
            >
              Submit Review
            </button>
          </form>
          
          {reviews.map((review, index) => (
            <div key={index} className="border-b py-2">
              <p>{review}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default ProductManual;