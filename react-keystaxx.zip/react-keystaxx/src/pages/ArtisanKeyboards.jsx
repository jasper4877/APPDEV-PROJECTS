import React from 'react';

const artisanKeyboards = [
  {
    id: 1,
    name: 'Woodland Whisper',
    description: 'A nature-inspired mechanical keyboard with hand-carved wooden keycaps',
    price: 299.99,
    imageUrl: '/path/to/woodland-keyboard.jpg'
  },
  {
    id: 2,
    name: 'Cyberpunk Edge',
    description: 'Futuristic design with LED-embedded keycaps and metallic finish',
    price: 449.99,
    imageUrl: '/path/to/cyberpunk-keyboard.jpg'
  },
  // Add more artisan keyboard designs
];

function ArtisanKeyboards() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Artisan Keyboard Collection</h1>
      
      <p className="text-lg mb-6">
        Discover our exclusive line of handcrafted mechanical keyboards that 
        blend technological innovation with artistic expression.
      </p>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {artisanKeyboards.map(keyboard => (
          <div 
            key={keyboard.id} 
            className="border rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
          >
            <img 
              src={keyboard.imageUrl} 
              alt={keyboard.name} 
              className="w-full h-64 object-cover"
            />
            <div className="p-4">
              <h2 className="text-2xl font-semibold mb-2">{keyboard.name}</h2>
              <p className="text-gray-600 mb-4">{keyboard.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-xl font-bold">${keyboard.price}</span>
                <button className="bg-blue-500 text-white px-4 py-2 rounded">
                  Learn More
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-8 bg-gray-100 p-6 rounded-lg">
        <h2 className="text-2xl font-semibold mb-4">Our Artisan Keyboard Philosophy</h2>
        <p>
          Each artisan keyboard is a unique masterpiece, meticulously crafted to 
          provide not just a typing experience, but a work of art that reflects 
          individual style and passion.
        </p>
      </div>
    </div>
  );
}

export default ArtisanKeyboards;