import React, { useState } from 'react';

const initialReviews = [
  {
    id: 1,
    name: 'Michael Johnson',
    rating: 5,
    comment: 'Absolutely love my KeyStaxx keyboard! The build quality is exceptional.',
    date: '2024-02-15'
  },
  {
    id: 2,
    name: 'Sarah Williams',
    rating: 4,
    comment: 'Great keyboard for professional use. Typing feels smooth and precise.',
    date: '2024-03-20'
  },
  // Add more initial reviews
];

function Reviews() {
  const [reviews, setReviews] = useState(initialReviews);
  const [newReview, setNewReview] = useState({
    name: '',
    rating: 5,
    comment: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewReview(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmitReview = (e) => {
    e.preventDefault();
    const submittedReview = {
      ...newReview,
      id: reviews.length + 1,
      date: new Date().toISOString().split('T')[0]
    };
    setReviews([submittedReview, ...reviews]);
    setNewReview({ name: '', rating: 5, comment: '' });
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Customer Reviews</h1>
      
      <div className="bg-gray-100 p-6 rounded-lg mb-6">
        <h2 className="text-2xl font-semibold mb-4">Write a Review</h2>
        <form onSubmit={handleSubmitReview}>
          <div className="mb-4">
            <input
              type="text"
              name="name"
              value={newReview.name}
              onChange={handleInputChange}
              placeholder="Your Name"
              className="w-full p-2 border rounded"
              required
            />
          </div>
          <div className="mb-4">
            <select
              name="rating"
              value={newReview.rating}
              onChange={handleInputChange}
              className="w-full p-2 border rounded"
            >
              {[5, 4, 3, 2, 1].map(rating => (
                <option key={rating} value={rating}>
                  {rating} Stars
                </option>
              ))}
            </select>
          </div>
          <div className="mb-4">
            <textarea
              name="comment"
              value={newReview.comment}
              onChange={handleInputChange}
              placeholder="Your Review"
              className="w-full p-2 border rounded"
              rows="4"
              required
            ></textarea>
          </div>
          <button 
            type="submit" 
            className="bg-blue-500 text-white px-4 py-2 rounded"
          >
            Submit Review
          </button>
        </form>
      </div>
      
      <div>
        <h2 className="text-2xl font-semibold mb-4">Customer Feedback</h2>
        {reviews.map(review => (
          <div key={review.id} className="bg-white border rounded p-4 mb-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-semibold">{review.name}</h3>
              <div className="flex">
                {[...Array(review.rating)].map((_, i) => (
                  <span key={i} className="text-yellow-500">★</span>
                ))}
              </div>
            </div>
            <p>{review.comment}</p>
            <p className="text-sm text-gray-500 mt-2">{review.date}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Reviews;